#!/bin/bash
set -e

echo "=== Pikachu Bot — Oracle Cloud Setup ==="

# Update system
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3 python3-pip python3-venv git

# Create bot directory
mkdir -p /home/ubuntu/pikachu-bot
cd /home/ubuntu/pikachu-bot

# Create virtualenv and install deps
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Create .env if not exists
if [ ! -f .env ]; then
    echo "TELEGRAM_BOT_TOKEN=YOUR_TOKEN_HERE" > .env
    echo "ORACLE_DEPLOY=1" >> .env
    echo ""
    echo ">>> IMPORTANT: Edit .env and set your TELEGRAM_BOT_TOKEN!"
    echo ">>> Run: nano /home/ubuntu/pikachu-bot/.env"
fi

# Install systemd service
sudo cp deploy/pikachu-bot.service /etc/systemd/system/pikachu-bot.service
sudo systemctl daemon-reload
sudo systemctl enable pikachu-bot
sudo systemctl start pikachu-bot

echo ""
echo "=== Done! ==="
echo "Check status : sudo systemctl status pikachu-bot"
echo "View logs    : sudo journalctl -u pikachu-bot -f"
echo "Restart      : sudo systemctl restart pikachu-bot"
echo "Stop         : sudo systemctl stop pikachu-bot"
