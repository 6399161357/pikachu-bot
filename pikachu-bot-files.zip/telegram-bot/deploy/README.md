# Oracle Cloud Free Tier — Deployment Guide

## Step 1 — Oracle Cloud VM banao

1. [oracle.com/cloud/free](https://www.oracle.com/cloud/free) pe account banao
2. **Compute → Instances → Create Instance**
3. Image: **Ubuntu 22.04**
4. Shape: **VM.Standard.E2.1.Micro** (Always Free)
5. SSH key generate karo ya apni upload karo — yeh download karo
6. Instance create karo

## Step 2 — Port 22 open karo (SSH ke liye)

Firewall mein port 22 already open hoga by default.

## Step 3 — Files VM pe copy karo

Apne local machine se (ya Replit shell se):

```bash
# Replit se sare bot files zip karo
zip -r pikachu-bot.zip telegram-bot/ --exclude "telegram-bot/__pycache__/*" --exclude "telegram-bot/gamebot.db"

# VM pe copy karo (apna IP aur key path daalo)
scp -i your-key.pem pikachu-bot.zip ubuntu@YOUR_VM_IP:/home/ubuntu/
```

## Step 4 — VM pe SSH karo

```bash
ssh -i your-key.pem ubuntu@YOUR_VM_IP
```

## Step 5 — Bot setup karo (ek command)

```bash
# Files extract karo
cd /home/ubuntu
unzip pikachu-bot.zip
mv telegram-bot pikachu-bot
cd pikachu-bot

# Setup script chalao
chmod +x deploy/setup.sh
./deploy/setup.sh
```

## Step 6 — Token set karo

```bash
nano /home/ubuntu/pikachu-bot/.env
```

Yahan likho:
```
TELEGRAM_BOT_TOKEN=apna_token_yahan_likho
ORACLE_DEPLOY=1
```

`Ctrl+X` → `Y` → `Enter` se save karo.

## Step 7 — Bot start karo

```bash
sudo systemctl restart pikachu-bot
sudo systemctl status pikachu-bot
```

Green **active (running)** dikhega toh bot chal raha hai 24/7!

---

## Useful Commands

| Kaam | Command |
|------|---------|
| Status check | `sudo systemctl status pikachu-bot` |
| Live logs | `sudo journalctl -u pikachu-bot -f` |
| Restart | `sudo systemctl restart pikachu-bot` |
| Stop | `sudo systemctl stop pikachu-bot` |
| Auto-start on reboot | Already enabled by setup.sh |

---

## Database backup (optional)

```bash
# Apne PC pe copy karo
scp -i your-key.pem ubuntu@YOUR_VM_IP:/home/ubuntu/pikachu-bot/gamebot.db ./gamebot_backup.db
```

---

## Notes

- Flask keep_alive Oracle pe automatically band ho jata hai (`ORACLE_DEPLOY=1` env se)
- Bot crash hone pe systemd automatically 5 seconds mein restart kar deta hai
- VM reboot hone pe bhi bot khud start ho jata hai
